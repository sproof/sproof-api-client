import de from './de'
import en from './en'

const lang = {de, en}

export default lang;