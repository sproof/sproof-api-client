const Master = require('./master');

class App {
    constructor() {
      Master();
    }
}

new App();
