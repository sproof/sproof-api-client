export function reset() {
  return {
    type: 'RESET'
  };
}